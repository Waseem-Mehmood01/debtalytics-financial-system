<?php

$user_id = $_SESSION['user_id'];
$company_id = $_SESSION['company_id'];

if (isset($_POST['btnSubmit'])) {

	@extract($_POST);

		DB::insert("matrics_intake", array(
			'date'=> $date,
			"inbound_apps"=> $inbound_apps,
            "out_bound_apps"=> $out_bound_apps,
            "inbound_new_leads"=> $inbound_new_leads,
            "today_schedule_patched"=> $today_schedule_patched,
            "sameday_patches"=> $sameday_patches,
            "patches_completed"=> $patches_completed,
			'num_cc'   => $num_cc,
			'num_of_deals'   => $num_of_deals,
			'number_of_new_untouched_leads'   => $number_of_new_untouched_leads,
			'user_id'   => $user_id,
			'company_id'   => $company_id,
			'created_on'    => $now
			));	
 	
 
	echo '<script type="text/javascript">
<!--
window.location = "index.php?route=modules/dataentry/viewmetricsintake"
//-->
</script>'
;

}


?><div class="main-content app-content mt-0">
                    <div class="side-app">

                        <!-- CONTAINER -->
                        <div class="main-container container-fluid">

                            <!-- PAGE-HEADER -->
                            <div class="page-header">
                                <h1 class="page-title">Company Targets</h1>
                                <div>
								<ol class="breadcrumb float-sm-right">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<!-- <li class="breadcrumb-item"><a href="index.php?route=modules/dataentry/viewsalesintake">Sales Intake</a></li> -->
									<li class="breadcrumb-item active">Add Company Targets</li>
								</ol>
                                </div>
                            </div>
                            <!-- PAGE-HEADER END -->








							<div class="row">
                                <div class="col-xl-6 col-lg-12">
                                    <div class="card">
                                        <div class="card-header">
										<h3 class="card-title">Add Company Targets</h3>
                                        </div>
                                        <div class="card-body">
										<form class="form-horizontal" action="" method="POST">
                                        <div class="col-md-9 mt-3 mb-3">
                                                <div class="input-group">
                                                    <div class="input-group-text">
                                                        <span class="fa fa-clock-o tx-16 lh-0 op-6"></span>
                                                    </div>
                                                    <input class="form-control" autocomplete="off" id="datepicker-month" name="months" placeholder="Select Month" type="text">
                                                </div>
                                            </div>
                                            <div class="col-md-9 mt-3 mb-3">
                                                <div class="input-group">
                                                    <div class="input-group-text">
                                                        <span class="fa fa-clock-o tx-16 lh-0 op-6"></span>
                                                    </div>
                                                    <input class="form-control" autocomplete="off" id="datepicker-year" name="years" placeholder="Select Year" type="text">
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <label class="col-md-12 form-label"for="company_target">Company Target</label>
                                            <input type="number" name="company_target" class="form-control" required id="company_target" placeholder="0.00"/>
                                            </div>
                                                <div class="card-footer text-end">
                                            <button type="submit" name="btnSubmit" class="btn btn-success my-1">Save</button>
                                            </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <!--CONTAINER CLOSED -->

                    </div>
                </div>